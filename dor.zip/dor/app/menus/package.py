# package.py — patched UI (Rich soft-pink), logic preserved
import json
import sys

import requests
from app.service.auth import AuthInstance
from app.client.engsel import get_family, get_package, get_addons, get_package_details, send_api_request, unsubscribe
from app.client.ciam import get_auth_code
from app.service.bookmark import BookmarkInstance
from app.client.purchase.redeem import settlement_bounty, settlement_loyalty, bounty_allotment
from app.menus.util import clear_screen, pause, display_html
from app.client.purchase.qris import show_qris_payment
from app.client.purchase.ewallet import show_multipayment
from app.client.purchase.balance import settlement_balance
from app.type_dict import PaymentItem
from app.menus.purchase import purchase_n_times, purchase_n_times_by_option_code
from app.menus.util import format_quota_byte
from app.service.decoy import DecoyInstance

# Try to import rich for nicer UI; fallback safely to prints
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.align import Align
except Exception:
    Console = None
    Panel = None
    Table = None
    Text = None
    Align = None

console = Console() if Console else None
ACCENT_PINK = "#ffb6c1"
SAFE_BORDER = ACCENT_PINK

# helper functions for safe rich printing
def rprint(s: str = "", style: str | None = None, end: str = "\n"):
    """Print using rich if available, otherwise plain print."""
    try:
        if console and Text:
            t = Text(str(s))
            if style:
                # allow passing styles like "bold #ffb6c1"
                t.stylize(style)
            console.print(t, end=end)
        else:
            print(s, end=end)
    except Exception:
        print(s, end=end)

def rpanel(renderable, title: str | None = None, border_style: str | None = SAFE_BORDER, width: int | None = None, padding=(1,1)):
    """Print a rich Panel if available, fallback to plain print of text."""
    try:
        if console and Panel:
            if title:
                console.print(Panel(renderable, title=title, border_style=border_style, width=width, padding=padding))
            else:
                console.print(Panel(renderable, border_style=border_style, width=width, padding=padding))
        else:
            # fallback: print text/plain
            if isinstance(renderable, (str, int, float)):
                print(str(renderable))
            else:
                # try json pretty
                try:
                    print(json.dumps(renderable, indent=2, ensure_ascii=False))
                except Exception:
                    print(renderable)
    except Exception:
        try:
            print(renderable)
        except Exception:
            pass

def rtable_from_rows(columns, rows, title=None):
    """Build and print a Table from columns and row-tuples. Returns table or text for panel."""
    try:
        if Table:
            tbl = Table(show_header=False, show_edge=False, expand=True)
            for col in columns:
                tbl.add_column(col)
            for row in rows:
                tbl.add_row(*[str(x) for x in row])
            return tbl
    except Exception:
        pass
    # fallback: return plain text
    lines = []
    for row in rows:
        lines.append("  ".join(str(x) for x in row))
    return "\n".join(lines)

# -------------------------
# package detail UI + logic
# -------------------------
def show_package_details(api_key, tokens, package_option_code, is_enterprise, option_order = -1):
    active_user = AuthInstance.active_user
    subscription_type = active_user.get("subscription_type", "")
    
    clear_screen()
    header = f"Detail Paket - {package_option_code}"
    rpanel(header, title="[bold]Detail Paket[/bold]", border_style=ACCENT_PINK)

    package = get_package(api_key, tokens, package_option_code)
    if not package:
        rprint("Failed to load package details.")
        pause()
        return False

    price = package["package_option"]["price"]
    detail = display_html(package["package_option"]["tnc"])
    validity = package["package_option"]["validity"]

    option_name = package.get("package_option", {}).get("name","")
    family_name = package.get("package_family", {}).get("name","")
    variant_name = package.get("package_detail_variant", "").get("name","")
    title = f"{family_name} - {variant_name} - {option_name}".strip()
    
    family_code = package.get("package_family", {}).get("package_family_code","")
    parent_code = package.get("package_addon", {}).get("parent_code","")
    if parent_code == "":
        parent_code = "N/A"
    
    token_confirmation = package["token_confirmation"]
    ts_to_sign = package["timestamp"]
    payment_for = package["package_family"]["payment_for"]
    
    payment_items = [
        PaymentItem(
            item_code=package_option_code,
            product_type="",
            item_price=price,
            item_name=f"{variant_name} {option_name}".strip(),
            tax=0,
            token_confirmation=token_confirmation,
        )
    ]
    
    # Summary panel
    summary_lines = []
    summary_lines.append(f"Nama: {title}")
    summary_lines.append(f"Harga: Rp {price}")
    summary_lines.append(f"Payment For: {payment_for}")
    summary_lines.append(f"Masa Aktif: {validity}")
    summary_lines.append(f"Point: {package['package_option'].get('point', 'N/A')}")
    summary_lines.append(f"Plan Type: {package['package_family'].get('plan_type', 'N/A')}")
    summary_lines.append(f"Family Code: {family_code}")
    summary_lines.append(f"Parent Code (for addon/dummy): {parent_code}")

    rpanel("\n".join(summary_lines), title=f"[bold]{title}[/bold]", border_style=ACCENT_PINK)

    benefits = package["package_option"].get("benefits", []) or []
    if benefits:
        rows = []
        for benefit in benefits:
            data_type = benefit.get('data_type', 'N/A')
            total = benefit.get('total', 0)
            if data_type == "VOICE" and total > 0:
                total_display = f"{total/60:.2f} menit"
            elif data_type == "TEXT" and total > 0:
                total_display = f"{total} SMS"
            elif data_type == "DATA" and total > 0:
                quota = int(total)
                if quota >= 1_000_000_000:
                    total_display = f"{quota / (1024 ** 3):.2f} GB"
                elif quota >= 1_000_000:
                    total_display = f"{quota / (1024 ** 2):.2f} MB"
                elif quota >= 1_000:
                    total_display = f"{quota / 1024:.2f} KB"
                else:
                    total_display = str(quota)
            else:
                total_display = f"{total} ({data_type})"
            rows.append((benefit.get("name",""), total_display))
        tbl = rtable_from_rows(["Benefit", "Total"], rows)
        rpanel(tbl, title="Benefits", border_style=ACCENT_PINK)

    addons = get_addons(api_key, tokens, package_option_code)
    try:
        rpanel(json.dumps(addons, indent=2, ensure_ascii=False), title="Addons", border_style=ACCENT_PINK)
    except Exception:
        rprint("Addons:")
        rprint(str(addons))

    try:
        rpanel(detail, title="S&K MyXL", border_style=ACCENT_PINK)
    except Exception:
        rprint(detail)

    in_package_detail_menu = True
    while in_package_detail_menu:
        # Options menu — show as simple numbered lines (keeps logic identical)
        options = [
            "1. Beli dengan Pulsa",
            "2. Beli dengan E-Wallet",
            "3. Bayar dengan QRIS",
            "4. Pulsa + Decoy",
            "5. Pulsa + Decoy V2",
            "6. QRIS + Decoy (+1K)",
            "7. QRIS + Decoy V2",
            "8. Pulsa N kali",
        ]
        if payment_for == "":
            payment_for = "BUY_PACKAGE"
        if payment_for == "REDEEM_VOUCHER":
            options.extend(["B. Ambil sebagai bonus (jika tersedia)", "BA. Kirim bonus (jika tersedia)", "L. Beli dengan Poin (jika tersedia)"])
        if option_order != -1:
            options.insert(0, "0. Tambah ke Bookmark")
        options.append("00. Kembali ke daftar paket")

        rpanel("\n".join(options), title="Options", border_style=ACCENT_PINK, padding=(0,1))

        choice = input("Pilihan: ")
        if choice == "00":
            return False
        elif choice == "0" and option_order != -1:
            success = BookmarkInstance.add_bookmark(
                family_code=package.get("package_family", {}).get("package_family_code",""),
                family_name=package.get("package_family", {}).get("name",""),
                is_enterprise=is_enterprise,
                variant_name=variant_name,
                option_name=option_name,
                order=option_order,
            )
            if success:
                rprint("Paket berhasil ditambahkan ke bookmark.")
            else:
                rprint("Paket sudah ada di bookmark.")
            pause()
            continue
        
        elif choice == '1':
            settlement_balance(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True
            )
            input("Silahkan cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '2':
            show_multipayment(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '3':
            show_qris_payment(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '4':
            # Balance with Decoy            
            decoy = DecoyInstance.get_decoy("balance")
            
            decoy_package_detail = get_package(
                api_key,
                tokens,
                decoy["option_code"],
            )
            
            if not decoy_package_detail:
                rprint("Failed to load decoy package details.")
                pause()
                return False

            payment_items.append(
                PaymentItem(
                    item_code=decoy_package_detail["package_option"]["package_option_code"],
                    product_type="",
                    item_price=decoy_package_detail["package_option"]["price"],
                    item_name=decoy_package_detail["package_option"]["name"],
                    tax=0,
                    token_confirmation=decoy_package_detail["token_confirmation"],
                )
            )

            overwrite_amount = price + decoy_package_detail["package_option"]["price"]
            res = settlement_balance(
                api_key,
                tokens,
                payment_items,
                payment_for,
                False,
                overwrite_amount=overwrite_amount,
            )
            
            if res and res.get("status", "") != "SUCCESS":
                error_msg = res.get("message", "Unknown error")
                if "Bizz-err.Amount.Total" in error_msg:
                    error_msg_arr = error_msg.split("=")
                    valid_amount = int(error_msg_arr[1].strip())
                    
                    rprint(f"Adjusted total amount to: {valid_amount}")
                    res = settlement_balance(
                        api_key,
                        tokens,
                        payment_items,
                        payment_for,
                        False,
                        overwrite_amount=valid_amount,
                    )
                    if res and res.get("status", "") == "SUCCESS":
                        rprint("Purchase successful!")
            else:
                rprint("Purchase successful!")
            pause()
            return True
        elif choice == '5':
            # Balance with Decoy v2 (use token confirmation from decoy)
            decoy = DecoyInstance.get_decoy("balance")
            
            decoy_package_detail = get_package(
                api_key,
                tokens,
                decoy["option_code"],
            )
            
            if not decoy_package_detail:
                rprint("Failed to load decoy package details.")
                pause()
                return False

            payment_items.append(
                PaymentItem(
                    item_code=decoy_package_detail["package_option"]["package_option_code"],
                    product_type="",
                    item_price=decoy_package_detail["package_option"]["price"],
                    item_name=decoy_package_detail["package_option"]["name"],
                    tax=0,
                    token_confirmation=decoy_package_detail["token_confirmation"],
                )
            )

            overwrite_amount = price + decoy_package_detail["package_option"]["price"]
            res = settlement_balance(
                api_key,
                tokens,
                payment_items,
                "🤫",
                False,
                overwrite_amount=overwrite_amount,
                token_confirmation_idx=1
            )
            
            if res and res.get("status", "") != "SUCCESS":
                error_msg = res.get("message", "Unknown error")
                if "Bizz-err.Amount.Total" in error_msg:
                    error_msg_arr = error_msg.split("=")
                    valid_amount = int(error_msg_arr[1].strip())
                    
                    rprint(f"Adjusted total amount to: {valid_amount}")
                    res = settlement_balance(
                        api_key,
                        tokens,
                        payment_items,
                        "🤫",
                        False,
                        overwrite_amount=valid_amount,
                        token_confirmation_idx=-1
                    )
                    if res and res.get("status", "") == "SUCCESS":
                        rprint("Purchase successful!")
            else:
                rprint("Purchase successful!")
            pause()
            return True
        elif choice == '6':
            # QRIS decoy + Rpx
            decoy = DecoyInstance.get_decoy("qris")
            
            decoy_package_detail = get_package(
                api_key,
                tokens,
                decoy["option_code"],
            )
            
            if not decoy_package_detail:
                rprint("Failed to load decoy package details.")
                pause()
                return False

            payment_items.append(
                PaymentItem(
                    item_code=decoy_package_detail["package_option"]["package_option_code"],
                    product_type="",
                    item_price=decoy_package_detail["package_option"]["price"],
                    item_name=decoy_package_detail["package_option"]["name"],
                    tax=0,
                    token_confirmation=decoy_package_detail["token_confirmation"],
                )
            )
            
            rprint("-"*55)
            rprint(f"Harga Paket Utama: Rp {price}")
            rprint(f"Harga Paket Decoy: Rp {decoy_package_detail['package_option']['price']}")
            rprint("Silahkan sesuaikan amount (trial & error, 0 = malformed)")
            rprint("-"*55)

            show_qris_payment(
                api_key,
                tokens,
                payment_items,
                "SHARE_PACKAGE",
                True,
                token_confirmation_idx=1
            )
            
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '7':
            # QRIS decoy + Rp0
            decoy = DecoyInstance.get_decoy("qris0")
            
            decoy_package_detail = get_package(
                api_key,
                tokens,
                decoy["option_code"],
            )
            
            if not decoy_package_detail:
                rprint("Failed to load decoy package details.")
                pause()
                return False

            payment_items.append(
                PaymentItem(
                    item_code=decoy_package_detail["package_option"]["package_option_code"],
                    product_type="",
                    item_price=decoy_package_detail["package_option"]["price"],
                    item_name=decoy_package_detail["package_option"]["name"],
                    tax=0,
                    token_confirmation=decoy_package_detail["token_confirmation"],
                )
            )
            
            rprint("-"*55)
            rprint(f"Harga Paket Utama: Rp {price}")
            rprint(f"Harga Paket Decoy: Rp {decoy_package_detail['package_option']['price']}")
            rprint("Silahkan sesuaikan amount (trial & error, 0 = malformed)")
            rprint("-"*55)

            show_qris_payment(
                api_key,
                tokens,
                payment_items,
                "SHARE_PACKAGE",
                True,
                token_confirmation_idx=1
            )
            
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '8':
            #Pulsa N kali
            use_decoy_for_n_times = input("Use decoy package? (y/n): ").strip().lower() == 'y'
            n_times_str = input("Enter number of times to purchase (e.g., 3): ").strip()

            delay_seconds_str = input("Enter delay between purchases in seconds (e.g., 25): ").strip()
            if not delay_seconds_str.isdigit():
                delay_seconds_str = "0"

            try:
                n_times = int(n_times_str)
                if n_times < 1:
                    raise ValueError("Number must be at least 1.")
            except ValueError:
                rprint("Invalid number entered. Please enter a valid integer.")
                pause()
                continue
            purchase_n_times_by_option_code(
                n_times,
                option_code=package_option_code,
                use_decoy=use_decoy_for_n_times,
                delay_seconds=int(delay_seconds_str),
                pause_on_success=False,
                token_confirmation_idx=1
            )
        elif choice.lower() == 'b':
            settlement_bounty(
                api_key=api_key,
                tokens=tokens,
                token_confirmation=token_confirmation,
                ts_to_sign=ts_to_sign,
                payment_target=package_option_code,
                price=price,
                item_name=variant_name
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice.lower() == 'ba':
            destination_msisdn = input("Masukkan nomor tujuan bonus (mulai dengan 62): ").strip()
            bounty_allotment(
                api_key=api_key,
                tokens=tokens,
                ts_to_sign=ts_to_sign,
                destination_msisdn=destination_msisdn,
                item_name=option_name,
                item_code=package_option_code,
                token_confirmation=token_confirmation,
            )
            pause()
            return True
        elif choice.lower() == 'l':
            settlement_loyalty(
                api_key=api_key,
                tokens=tokens,
                token_confirmation=token_confirmation,
                ts_to_sign=ts_to_sign,
                payment_target=package_option_code,
                price=price,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        else:
            rprint("Purchase cancelled.")
            return False
    pause()
    sys.exit(0)

# -------------------------
# get_packages_by_family
# -------------------------
def get_packages_by_family(
    family_code: str,
    is_enterprise: bool | None = None,
    migration_type: str | None = None
):
    api_key = AuthInstance.api_key
    tokens = AuthInstance.get_active_tokens()
    if not tokens:
        rprint("No active user tokens found.")
        pause()
        return None
    
    packages = []
    
    data = get_family(
        api_key,
        tokens,
        family_code,
        is_enterprise,
        migration_type
    )
    
    if not data:
        rprint("Failed to load family data.")
        pause()
        return None
    price_currency = "Rp"
    rc_bonus_type = data["package_family"].get("rc_bonus_type", "")
    if rc_bonus_type == "MYREWARDS":
        price_currency = "Poin"
    
    in_package_menu = True
    while in_package_menu:
        clear_screen()
        header = [
            f"Family Name: {data['package_family']['name']}",
            f"Family Code: {family_code}",
            f"Family Type: {data['package_family'].get('package_family_type','')}",
            f"Variant Count: {len(data['package_variants'])}"
        ]
        rpanel("\n".join(header), title="Family Info", border_style=ACCENT_PINK, padding=(0,1))

        rprint("Paket Tersedia")
        package_variants = data["package_variants"]
        
        option_number = 1
        variant_number = 1
        
        for variant in package_variants:
            variant_name = variant["name"]
            variant_code = variant["package_variant_code"]
            rprint(f" Variant {variant_number}: {variant_name}")
            rprint(f" Code: {variant_code}")
            for option in variant["package_options"]:
                option_name = option["name"]
                
                packages.append({
                    "number": option_number,
                    "variant_name": variant_name,
                    "option_name": option_name,
                    "price": option["price"],
                    "code": option["package_option_code"],
                    "option_order": option["order"]
                })
                                
                rprint(f"   {option_number}. {option_name} - {price_currency} {option['price']}")
                
                option_number += 1
            
            if variant_number < len(package_variants):
                rprint("-------------------------------------------------------")
            variant_number += 1
        rprint("-------------------------------------------------------")

        rprint("00. Kembali ke menu utama")
        rprint("-------------------------------------------------------")
        pkg_choice = input("Pilih paket (nomor): ")
        if pkg_choice == "00":
            in_package_menu = False
            return None
        
        if isinstance(pkg_choice, str) == False or not pkg_choice.isdigit():
            rprint("Input tidak valid. Silakan masukan nomor paket.")
            continue
        
        selected_pkg = next((p for p in packages if p["number"] == int(pkg_choice)), None)
        
        if not selected_pkg:
            rprint("Paket tidak ditemukan. Silakan masukan nomor yang benar.")
            continue
        
        show_package_details(
            api_key,
            tokens,
            selected_pkg["code"],
            is_enterprise,
            option_order=selected_pkg["option_order"],
        )
        
    return packages

# -------------------------
# fetch_my_packages
# -------------------------
def fetch_my_packages():
    in_my_packages_menu = True
    while in_my_packages_menu:
        api_key = AuthInstance.api_key
        tokens = AuthInstance.get_active_tokens()
        if not tokens:
            rprint("No active user tokens found.")
            pause()
            return None
        
        id_token = tokens.get("id_token")
        
        path = "api/v8/packages/quota-details"
        
        payload = {
            "is_enterprise": False,
            "lang": "en",
            "family_member_id": ""
        }
        
        rprint("Fetching my packages...")
        res = send_api_request(api_key, path, payload, id_token, "POST")
        if res.get("status") != "SUCCESS":
            rprint("Failed to fetch packages")
            rprint(f"Response: {res}")
            pause()
            return None
        
        quotas = res["data"]["quotas"]
        
        clear_screen()
        rpanel("My Packages", title="My Packages", border_style=ACCENT_PINK)
        my_packages =[]
        num = 1
        for quota in quotas:
            quota_code = quota["quota_code"]
            group_code = quota["group_code"]
            group_name = quota["group_name"]
            quota_name = quota["name"]
            family_code = "N/A"
            
            product_subscription_type = quota.get("product_subscription_type", "")
            product_domain = quota.get("product_domain", "")
            
            benefit_infos = []
            benefits = quota.get("benefits", []) or []
            if len(benefits) > 0:
                for benefit in benefits:
                    benefit_id = benefit.get("id", "")
                    name = benefit.get("name", "")
                    data_type = benefit.get("data_type", "N/A")
                    benefit_info = "  -----------------------------------------------------\n"
                    benefit_info += f"  ID    : {benefit_id}\n"
                    benefit_info += f"  Name  : {name}\n"
                    benefit_info += f"  Type  : {data_type}\n"
                    

                    remaining = benefit.get("remaining", 0)
                    total = benefit.get("total", 0)

                    if data_type == "DATA":
                        remaining_str = format_quota_byte(remaining)
                        total_str = format_quota_byte(total)
                        
                        benefit_info += f"  Kuota : {remaining_str} / {total_str}"
                    elif data_type == "VOICE":
                        benefit_info += f"  Kuota : {remaining/60:.2f} / {total/60:.2f} menit"
                    elif data_type == "TEXT":
                        benefit_info += f"  Kuota : {remaining} / {total} SMS"
                    else:
                        benefit_info += f"  Kuota : {remaining} / {total}"

                    benefit_infos.append(benefit_info)
                
            
            rprint(f"fetching package no. {num} details...")
            package_details = get_package(api_key, tokens, quota_code)
            if package_details:
                family_code = package_details["package_family"]["package_family_code"]
            
            # Build a compact panel per package
            pkg_lines = [
                f"Package {num}",
                f"Name: {quota_name}",
            ]
            if benefit_infos:
                pkg_lines.append("Benefits:")
                for bi in benefit_infos:
                    pkg_lines.append(bi)
            pkg_lines.extend([
                f"Group Name: {group_name}",
                f"Quota Code: {quota_code}",
                f"Family Code: {family_code}",
                f"Group Code: {group_code}",
            ])
            rpanel("\n".join(pkg_lines), title=f"Package {num}", border_style=ACCENT_PINK, padding=(0,1))
            
            my_packages.append({
                "number": num,
                "name": quota_name,
                "quota_code": quota_code,
                "product_subscription_type": product_subscription_type,
                "product_domain": product_domain,
            })
            
            num += 1
        
        # Footer / commands
        rprint("")
        rprint("Input package number to view detail.")
        rprint("Input del <package number> to unsubscribe from a package.")
        rprint("Input 00 to return to main menu.")
        choice = input("Choice: ")
        if choice == "00":
            in_my_packages_menu = False

        # Handle selecting package to view detail
        if choice.isdigit() and int(choice) > 0 and int(choice) <= len(my_packages):
            selected_pkg = next((pkg for pkg in my_packages if pkg["number"] == int(choice)), None)
            if not selected_pkg:
                rprint("Paket tidak ditemukan. Silakan masukan nomor yang benar.")
                pause()
                continue
            
            _ = show_package_details(api_key, tokens, selected_pkg["quota_code"], False)
        
        elif choice.startswith("del "):
            del_parts = choice.split(" ")
            if len(del_parts) != 2 or not del_parts[1].isdigit():
                rprint("Invalid input for delete command.")
                pause()
                continue
            
            del_number = int(del_parts[1])
            del_pkg = next((pkg for pkg in my_packages if pkg["number"] == del_number), None)
            if not del_pkg:
                rprint("Package not found for deletion.")
                pause()
                continue
            
            confirm = input(f"Are you sure you want to unsubscribe from package  {del_number}. {del_pkg['name']}? (y/n): ")
            if confirm.lower() == 'y':
                rprint(f"Unsubscribing from package number {del_pkg['name']}...")
                # NOTE: keep original correct argument order (domain, then subscription_type)
                success = unsubscribe(api_key, tokens, del_pkg["quota_code"], del_pkg["product_domain"], del_pkg["product_subscription_type"])
                if success:
                    rprint("Successfully unsubscribed from the package.")
                else:
                    rprint("Failed to unsubscribe from the package.")
            else:
                rprint("Unsubscribe cancelled.")
            pause()

# end of file