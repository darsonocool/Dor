# util.py (modified: ASCII colored soft-pink + opening animation)
from html.parser import HTMLParser
import os
import re
import textwrap
import sys
import time
from typing import Optional

# Rich for coloring & nicer prompts
try:
    from rich.console import Console
    from rich.text import Text
    from rich.panel import Panel
except Exception:
    Console = None
    Text = None
    Panel = None

console = Console() if Console else None
ACCENT_PINK = "#ffb6c1"

# ASCII art (kept as original but can be replaced)
ASCII_ART = r"""
..........................................................................
..........................................................................
..........................................................................
..........................................................................
..............................:--::::.....................................
.......................:::::::=*--=+#%@@#=-::.............................
......................-@#**++%%#*%*==%+-=*-=%@-......:+*--#+:.............
.....................=@+%%%+%*%-#@%*=-==*%+----%=..:=-------#.............
.....................%=-*+=%@=:-+##=::=+*=#**---=#----------*=............
....................=%*@@*:+*.............=--++---=---------*=............
....................###:.:::=#%#****#*=-::+---+****++++==---*+:...........
...................:%#=..:%*:-*%%#+.....:-*---+.==***=:......:-+#%#*=--:..
...................:%#+.:*:..............+=---+.%-===#::::-=#%@@%*-.......
...................:%#+:::..............-+=--==.-#=----------=............
.................:=:+@#................:#:---*..-#=+*-------=:............
...............:+-*#+%@-..................--=:..+*=%#-------*.............
.............=+-*-.-*#@#:.................-*:.-%-++*#-------*-............
..........:=+===#%+:::-+#:.........:-:....=:+%-..#+##-------*-............
........:#-*%+:......=*+-#=:......:#@@@@+-%+:...:#----------=+............
......:%%-::.........+*+---=@%+-:-+#@@@+:::*%%..+------------+............
......-:.............##+--------=-+=-.........:%#=----------#+............
.....................+=*--------++:+.........=+---*+-------+@:............
.....................=+--------%+::=........+-------#-----+@=.............
...................:++==-----=@=..+-......-*---------*+-=%%+:.............
...................-+===----+%*:.:@:.....:*-----------%@*::...............
...................-%-----*@=-#..++.....:*-------*@@*:.=*.................
...................:*#*%*=----*.:#:.....=----*%+-:......:#:...............
.................=##===------+:.=+......+--%=:........-=-*++:.............
..............-%#-....:*:----+.:@:......=-*:.........=-.-%:*=-............
.............:#=-%:....=:----+:*=.......=*.............+*:*-:+............
.............-=:::........+-*.-#........+:............:-.-:.=+............
..........................*=.-@-........-:................................
"""

def _print_plain(text: str):
    """Fallback plain print when Rich unavailable."""
    print(text)

def show_ascii_animation(ascii_art: str = ASCII_ART, line_delay: float = 0.02, char_delay: Optional[float] = None, centered: bool = False):
    """
    Show ascii art with simple animation.
    - line_delay: delay between lines (seconds)
    - char_delay: if set, prints each character with this delay (typewriter)
    - centered: center lines to terminal width if possible
    """
    # Determine terminal width for centering
    try:
        width = os.get_terminal_size().columns
    except Exception:
        width = 80

    if Console and console:
        # Use rich Text with accent color
        if char_delay is None:
            for line in ascii_art.splitlines():
                out_line = line
                if centered:
                    pad = max(0, (width - len(line)) // 2)
                    out_line = " " * pad + line
                txt = Text(out_line, style=ACCENT_PINK)
                console.print(txt)
                time.sleep(line_delay)
        else:
            # typewriter per-character (slower)
            for line in ascii_art.splitlines():
                out_line = line
                if centered:
                    pad = max(0, (width - len(line)) // 2)
                    if pad:
                        sys.stdout.write(" " * pad)
                for ch in out_line:
                    # print using console's capture to keep colors
                    try:
                        # small optimization: print chunks rather than char-by-char console.print
                        sys.stdout.write(f"\033[38;2;255;182;193m{ch}\033[0m")
                    except Exception:
                        sys.stdout.write(ch)
                    sys.stdout.flush()
                    time.sleep(char_delay)
                sys.stdout.write("\n")
                sys.stdout.flush()
            # ensure console prints end color reset
            try:
                console.print("")  # noop to flush rich
            except Exception:
                pass
    else:
        # Fallback plain printing (no color)
        if char_delay is None:
            for line in ascii_art.splitlines():
                print(line)
                time.sleep(line_delay)
        else:
            for line in ascii_art.splitlines():
                for ch in line:
                    print(ch, end="", flush=True)
                    time.sleep(char_delay)
                print()

def clear_screen(animate: bool = True, ascii_art: str = ASCII_ART, line_delay: float = 0.02, char_delay: Optional[float] = None, centered: bool = False):
    """
    Clear terminal and optionally show colored ascii animation.
    - animate: whether to show animation after clearing
    - line_delay/char_delay: passed to show_ascii_animation
    - centered: center ascii art horizontally
    """
    # clear terminal
    os.system('cls' if os.name == 'nt' else 'clear')
    if not animate:
        # simply print static colored art once
        if Console and console:
            console.print(Text(ascii_art, style=ACCENT_PINK))
        else:
            print(ascii_art)
        return

    try:
        show_ascii_animation(ascii_art=ascii_art, line_delay=line_delay, char_delay=char_delay, centered=centered)
    except Exception:
        # fallback to plain print if any animation error
        try:
            if Console and console:
                console.print(Text(ascii_art, style=ACCENT_PINK))
            else:
                print(ascii_art)
        except Exception:
            print(ascii_art)

def pause(msg: str = "\nPress enter to continue..."):
    """
    Pause prompt; colored if Rich available.
    """
    try:
        if Console and console:
            prompt = Text(msg, style=ACCENT_PINK)
            # If prompt includes newline, print then input
            if "\n" in msg:
                console.print(prompt)
                input()
            else:
                # fallback to plain input with stripped tags
                input(prompt.plain + " ")
        else:
            input(msg)
    except Exception:
        try:
            input(msg)
        except Exception:
            pass

class HTMLToText(HTMLParser):
    def __init__(self, width=80):
        super().__init__()
        self.width = width
        self.result = []
        self.in_li = False

    def handle_starttag(self, tag, attrs):
        if tag == "li":
            self.in_li = True
        elif tag == "br":
            self.result.append("\n")

    def handle_endtag(self, tag):
        if tag == "li":
            self.in_li = False
            self.result.append("\n")

    def handle_data(self, data):
        text = data.strip()
        if text:
            if self.in_li:
                self.result.append(f"- {text}")
            else:
                self.result.append(text)

    def get_text(self):
        # Join and clean multiple newlines
        text = "".join(self.result)
        text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
        # Wrap lines nicely
        return "\n".join(textwrap.wrap(text, width=self.width, replace_whitespace=False))

def display_html(html_text, width=80):
    parser = HTMLToText(width=width)
    parser.feed(html_text)
    return parser.get_text()

def format_quota_byte(quota_byte: int) -> str:
    GB = 1024 ** 3 
    MB = 1024 ** 2
    KB = 1024

    if quota_byte >= GB:
        return f"{quota_byte / GB:.2f} GB"
    elif quota_byte >= MB:
        return f"{quota_byte / MB:.2f} MB"
    elif quota_byte >= KB:
        return f"{quota_byte / KB:.2f} KB"
    else:
        return f"{quota_byte} B"