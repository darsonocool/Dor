# app/menus/account.py
# Rich-styled account menus (soft pink accent)
from app.client.ciam import get_otp, submit_otp
from app.menus.util import clear_screen, pause
from app.service.auth import AuthInstance

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt
from rich.align import Align
from rich.text import Text
from rich import box

console = Console()
ACCENT = "#ffb6c1"  # soft pink

def show_login_menu():
    """
    Display login menu (styled).
    """
    clear_screen()
    title = Text("Login ke MyXL", style="bold white on " + ACCENT)
    console.print(Panel(Align.center(title), expand=True, box=box.ROUNDED, style=""))
    menu = Table.grid(padding=(0,1))
    menu.add_column(justify="left")
    menu.add_row("[bold]1[/bold]. Request OTP")
    menu.add_row("[bold]2[/bold]. Submit OTP")
    menu.add_row("[bold]99[/bold]. Tutup aplikasi")
    console.print(Panel(menu, title="Pilihan", subtitle="Masukkan pilihan", style=""))

def login_prompt(api_key: str):
    """
    Prompt user for phone number and OTP, perform login via get_otp / submit_otp.
    Returns (phone_number, refresh_token) on success, or (None, None) on failure.
    """
    clear_screen()
    console.print(Panel(Text("Login ke MyXL", justify="center", style="bold"), style=ACCENT, box=box.ROUNDED))
    console.print()  # spacer

    # Ask phone number
    phone_number = Prompt.ask("[white]Masukan nomor XL (Contoh 6281234567890)[/white]", default="")
    phone_number = phone_number.strip()

    # Validate
    if not phone_number.startswith("628") or len(phone_number) < 10 or len(phone_number) > 14:
        console.print("[red]Nomor tidak valid. Pastikan nomor diawali dengan '628' dan memiliki panjang yang benar.[/red]")
        return None, None

    try:
        subscriber_id = get_otp(phone_number)
        if not subscriber_id:
            return None, None
        console.print(f"[green]OTP Berhasil dikirim ke nomor {phone_number}.[/green]")

        try_count = 5
        while try_count > 0:
            console.print(f"[dim]Sisa percobaan: {try_count}[/dim]")
            otp = Prompt.ask("[white]Masukkan OTP yang telah dikirim[/white]", default="").strip()
            if not otp.isdigit() or len(otp) != 6:
                console.print("[red]OTP tidak valid. Pastikan OTP terdiri dari 6 digit angka.[/red]")
                continue

            tokens = submit_otp(api_key, "SMS", phone_number, otp)
            if not tokens:
                console.print("[red]OTP salah. Silahkan coba lagi.[/red]")
                try_count -= 1
                continue

            console.print("[green]Berhasil login![/green]")
            return phone_number, tokens.get("refresh_token")

        console.print("[red]Gagal login setelah beberapa percobaan. Silahkan coba lagi nanti.[/red]")
        return None, None
    except Exception as e:
        console.print(f"[red]Gagal login: {e}[/red]")
        return None, None

def show_account_menu():
    """
    Main account menu loop (styled with Rich).
    Returns active_user number (string/int) if user chooses to go back with an account selected.
    """
    clear_screen()
    AuthInstance.load_tokens()
    users = AuthInstance.refresh_tokens
    active_user = AuthInstance.get_active_user()

    in_account_menu = True
    add_user = False

    while in_account_menu:
        clear_screen()
        header = Text("Manajemen Akun", style="bold")
        console.print(Panel(header, style=ACCENT, box=box.ROUNDED))

        # If no active user or we need to add user, go through login prompt
        if AuthInstance.get_active_user() is None or add_user:
            number, refresh_token = login_prompt(AuthInstance.api_key)
            if not refresh_token:
                console.print("[red]Gagal menambah akun. Silahkan coba lagi.[/red]")
                pause()
                continue

            try:
                # original code used int(number) — keep that behavior (may be expected by AuthInstance)
                AuthInstance.add_refresh_token(int(number), refresh_token)
            except Exception:
                # fallback: try raw number if int conversion fails
                try:
                    AuthInstance.add_refresh_token(number, refresh_token)
                except Exception as e:
                    console.print(f"[red]Gagal menambah token: {e}[/red]")
                    pause()
                    continue

            AuthInstance.load_tokens()
            users = AuthInstance.refresh_tokens
            active_user = AuthInstance.get_active_user()

            if add_user:
                add_user = False
            continue

        # Show stored accounts in a table
        tbl = Table(box=box.SIMPLE_HEAVY, expand=True)
        tbl.add_column("No", justify="right", width=4)
        tbl.add_column("Nomor", justify="left")
        tbl.add_column("Subscription", justify="center")
        tbl.add_column("Aktif", justify="center", width=6)

        if not users or len(users) == 0:
            console.print(Panel("[yellow]Tidak ada akun tersimpan.[/yellow]", title="Akun Tersimpan", expand=True))
        else:
            for idx, user in enumerate(users):
                is_active = active_user and user.get("number") == active_user.get("number")
                active_marker = "✅" if is_active else ""
                number = str(user.get("number", ""))
                # keep spacing similar to original display
                tbl.add_row(str(idx + 1), number, str(user.get("subscription_type", "")).center(12), active_marker)
            console.print(Panel(tbl, title="Akun Tersimpan", expand=True))

        # Commands panel
        help_tbl = Table.grid(expand=True)
        help_tbl.add_column(ratio=1)
        help_tbl.add_column(ratio=2)
        help_tbl.add_row("[bold]0[/bold]", "Tambah Akun")
        help_tbl.add_row("[bold]del <nomor urut>[/bold]", "Hapus akun tertentu")
        help_tbl.add_row("[bold]00[/bold]", "Kembali ke menu utama")
        help_tbl.add_row("[bold]Pilih nomor[/bold]", "Masuk/ganti akun aktif")
        console.print(Panel(help_tbl, title="Command", style=""))

        # Get user input
        input_str = Prompt.ask("[white]Pilihan[/white]", default="").strip()

        if input_str == "00":
            in_account_menu = False
            return active_user["number"] if active_user else None
        elif input_str == "0":
            add_user = True
            continue
        elif input_str.isdigit() and 1 <= int(input_str) <= (len(users) if users else 0):
            selected_user = users[int(input_str) - 1]
            return selected_user.get("number")
        elif input_str.startswith("del "):
            parts = input_str.split()
            if len(parts) == 2 and parts[1].isdigit():
                del_index = int(parts[1])
                if del_index < 1 or del_index > len(users):
                    console.print("[red]Nomor urut tidak valid.[/red]")
                    pause()
                    continue

                # Prevent deleting the active user here
                if active_user and users[del_index - 1].get("number") == active_user.get("number"):
                    console.print("[red]Tidak dapat menghapus akun aktif. Silahkan ganti akun terlebih dahulu.[/red]")
                    pause()
                    continue

                user_to_delete = users[del_index - 1]
                confirm = Prompt.ask(f"Yakin ingin menghapus akun {user_to_delete.get('number')}? (y/n)", default="n").strip().lower()
                if confirm == 'y':
                    try:
                        AuthInstance.remove_refresh_token(user_to_delete.get("number"))
                        # reload lists
                        users = AuthInstance.refresh_tokens
                        active_user = AuthInstance.get_active_user()
                        console.print("[green]Akun berhasil dihapus.[/green]")
                        pause()
                    except Exception as e:
                        console.print(f"[red]Gagal menghapus akun: {e}[/red]")
                        pause()
                else:
                    console.print("[yellow]Penghapusan akun dibatalkan.[/yellow]")
                    pause()
            else:
                console.print("[red]Perintah tidak valid. Gunakan format: del <nomor urut>[/red]")
                pause()
            continue
        else:
            console.print("[red]Input tidak valid. Silahkan coba lagi.[/red]")
            pause()
            continue